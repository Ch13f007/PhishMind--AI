"""
PhishMind AI — Backend Entry Point
FastAPI application for adaptive phishing awareness platform
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(
    title="PhishMind AI",
    description="Adaptive AI-Powered Phishing Awareness for African SMEs",
    version="0.1.0"
)

# CORS — allow React frontend to connect
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
def root():
    return {"message": "PhishMind AI API is running 🎣"}


@app.get("/health")
def health_check():
    return {"status": "healthy", "version": "0.1.0"}


# TODO: Register routers
# from routes import campaigns, employees, tracking
# app.include_router(campaigns.router, prefix="/api/campaigns")
# app.include_router(employees.router, prefix="/api/employees")
# app.include_router(tracking.router, prefix="/api/track")
